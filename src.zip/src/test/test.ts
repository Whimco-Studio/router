import { t } from "@rbxts/t";
import { registerRoute, use } from "../core/router";
import { routerAuth, routerLogger } from "../core/middleware";

registerRoute({
	name: "CreatePet",
	schema: t.interface({
		name: t.string,
		type: t.keyOf({ dog: true, cat: true }),
	}),
	middleware: [routerLogger],
	handler: (ctx) => {
		const payload = ctx.payload; // payload is typed
	},
});
