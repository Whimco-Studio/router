import { t } from "@rbxts/t";
import { registerRoutes } from "../core/router";

registerRoutes("pets", [
	{
		name: "create",
		schema: t.interface({
			name: t.string,
			type: t.keyOf({ cat: true, dog: true }),
		}),
		handler: ({ player, payload }) => {
			// logic here
			return { success: true };
		},
	},

	{
		name: "feed",
		schema: t.interface({ id: t.string }),
		handler: ({ player, payload }) => {
			// feed logic
			return { success: true };
		},
	},
]);
